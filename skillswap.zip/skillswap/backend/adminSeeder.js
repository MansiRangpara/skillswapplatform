import mongoose from 'mongoose';
import dotenv from 'dotenv';
import bcrypt from 'bcryptjs';
import User from './models/User.js';

dotenv.config();

await mongoose.connect(process.env.MONGO_URI);
const existingAdmin = await User.findOne({ email: 'admin@swap.com' });

if (!existingAdmin) {
  const hashedPassword = await bcrypt.hash('admin123', 10);
  const admin = new User({
    name: 'Admin',
    email: 'admin@swap.com',
    password: hashedPassword,
    role: 'admin'
  });
  await admin.save();
  console.log('✅ Admin user created.');
} else {
  console.log('⚠️ Admin already exists.');
}
await mongoose.disconnect();
