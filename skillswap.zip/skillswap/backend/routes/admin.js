import express from 'express';
import User from '../models/User.js';
import Swap from '../models/Swap.js';
import { verifyToken as authMiddleware } from '../Middleware/authMiddleware.js';

const router = express.Router();
let currentMessage = '';

// Admin-only middleware
const adminOnly = async (req, res, next) => {
  if (!req.user || req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Access denied: Admins only' });
  }
  next();
};

// Message routes
router.get('/message', (req, res) => {
  res.json({ message: currentMessage });
});
router.post('/message', authMiddleware, adminOnly, (req, res) => {
  currentMessage = req.body.message;
  res.json({ message: 'Message posted' });
});

// Export report
router.get('/export', authMiddleware, adminOnly, async (req, res) => {
  const { type } = req.query;
  if (type === 'users') {
    const users = await User.find();
    return res.json(users);
  } else if (type === 'swaps') {
    const swaps = await Swap.find();
    return res.json(swaps);
  } else {
    return res.status(400).json({ error: 'Invalid type' });
  }
});

// Ban/unban user
router.put('/ban/:userId', authMiddleware, adminOnly, async (req, res) => {
  const { userId } = req.params;
  const { ban } = req.body;

  try {
    const updated = await User.findByIdAndUpdate(userId, { isBanned: ban }, { new: true });
    res.json({ message: `User ${ban ? 'banned' : 'unbanned'}`, user: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update user status' });
  }
});

// Approve/reject skills
router.put('/moderate/:userId', authMiddleware, adminOnly, async (req, res) => {
  const { userId } = req.params;
  const { approved } = req.body;

  try {
    const updated = await User.findByIdAndUpdate(userId, { isApproved: approved }, { new: true });
    res.json({ message: `Skill descriptions ${approved ? 'approved' : 'rejected'}`, user: updated });
  } catch (err) {
    res.status(500).json({ error: 'Failed to update approval' });
  }
});

export default router;
