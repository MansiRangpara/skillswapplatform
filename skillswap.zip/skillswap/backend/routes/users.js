import express from 'express';
import User from '../models/User.js';
const router = express.Router();
import jwt from 'jsonwebtoken';
import upload from '../Middleware/upload.js';

router.post('/', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    res.status(201).json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.get('/', async (req, res) => {
  try {
    const users = await User.find();
    res.status(200).json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
router.get('/me', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'No or invalid token' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const user = await User.findById(decoded.userId);
    if (!user) return res.status(404).json({ error: 'User not found' });

    res.json(user);
  } catch (err) {
    console.error('GET /me error:', err.message);
    res.status(400).json({ error: 'Invalid token' });
  }
});
router.put('/me', async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: 'Missing or invalid token' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);

    const updatedUser = await User.findByIdAndUpdate(
      decoded.userId,
      {
        name: req.body.name,
        skillsOffered: req.body.skillsOffered,
        skillsWanted: req.body.skillsWanted,
      },
      { new: true }
    );

    if (!updatedUser) {
      return res.status(404).json({ error: 'User not found' });
    }

    res.json(updatedUser);
  } catch (err) {
    console.error('Update profile error:', err.message);
    res.status(400).json({ error: 'Profile update failed' });
  }
});
router.put('/me/photo', upload.single('profilePhoto'), async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.userId);

    if (!user) return res.status(404).json({ error: 'User not found' });

    user.profilePhoto = `http://localhost:5000/uploads/${req.file.filename}`;
    await user.save();

    res.json({ message: 'Photo updated', profilePhoto: user.profilePhoto });
  } catch (err) {
    console.error('Upload error:', err);
    res.status(400).json({ error: 'Upload failed' });
  }
});
// ✅ Search users by skill (e.g., /api/users/search?skill=React)
router.get('/search', async (req, res) => {
  const skill = req.query.skill?.trim();
  if (!skill) {
    return res.status(400).json({ error: 'Skill is required' });
  }

  try {
    const regex = new RegExp(skill, 'i'); // case-insensitive
    const users = await User.find({
      $or: [
        { skillsOffered: { $regex: regex } },
        { skillsWanted: { $regex: regex } }
      ]
    });

    res.json(users);
  } catch (err) {
    console.error('Search error:', err.message);
    res.status(500).json({ error: 'Search failed' });
  }
});




export default router;