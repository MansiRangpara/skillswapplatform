import express from 'express';
import Swap from '../models/Swap.js';

import jwt from 'jsonwebtoken';
const router = express.Router();
router.post('/', async (req, res) => {
  const token = req.headers.authorization?.split(' ')[1];

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const requesterId = decoded.userId;

    const { recipientId, skillRequested, skillOffered, message } = req.body;

    if (!recipientId || !skillRequested || !skillOffered) {
      return res.status(400).json({ error: 'Missing required fields' });
    }

    const swap = new Swap({
      requester: requesterId,
      recipient: recipientId,
      skillRequested,
      skillOffered,
      message
    });

    await swap.save();
    res.status(201).json({ message: 'Swap request sent!', swap });
  } catch (err) {
  console.error('Swap request error:', err.message);
  console.error(err.stack);
  res.status(400).json({ error: 'Invalid token or data' });
}

});



router.get('/', async (req, res) => {
  try {
    const swaps = await Swap.find();
    res.status(200).json(swaps);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.put('/:id', async (req, res) => {
  try {
    const swap = await Swap.findByIdAndUpdate(req.params.id, req.body, { new: true });
    res.status(200).json(swap);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

router.delete('/:id', async (req, res) => {
  try {
    await Swap.findByIdAndDelete(req.params.id);
    res.status(200).json({ message: 'Swap deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});
router.get('/my-requests', async (req, res) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const userId = decoded.userId;

    const swaps = await Swap.find({ requester: userId })
      .populate('recipient', 'name email') // Optional: show recipient info
      .sort({ createdAt: -1 });

    res.json(swaps);
  } catch (err) {
    console.error('❌ Error fetching my swap requests:', err);
    res.status(400).json({ error: 'Failed to fetch swap requests' });
  }
});
export default router;