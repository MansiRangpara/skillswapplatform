
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const SwapForm = ({ onSwapCreated }) => {
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    requesterId: '',
    receiverId: '',
    skillRequested: '',
    skillOffered: '',
  });

  useEffect(() => {
    axios.get('http://localhost:5000/api/users').then(res => setUsers(res.data));
  }, []);

  const handleChange = e => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/swaps', formData);
    onSwapCreated();
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '2rem' }}>
      <h3>Create Swap Request</h3>
      <select name='requesterId' onChange={handleChange} required>
        <option value=''>Select Requester</option>
        {users.map(u => <option value={u._id} key={u._id}>{u.name}</option>)}
      </select><br />
      <select name='receiverId' onChange={handleChange} required>
        <option value=''>Select Receiver</option>
        {users.map(u => <option value={u._id} key={u._id}>{u.name}</option>)}
      </select><br />
      <input name='skillRequested' placeholder='Skill Requested' onChange={handleChange} /><br />
      <input name='skillOffered' placeholder='Skill Offered' onChange={handleChange} /><br />
      <button type='submit'>Submit</button>
    </form>
  );
};

export default SwapForm;
