import React, { useState } from 'react';
import axios from 'axios';

const Login = ({ onLogin, isAdmin = false }) => {
  const [email, setEmail] = useState(isAdmin ? 'admin@swap.com' : '');
  const [password, setPassword] = useState('');

  const handleLogin = async (e) => {
    e.preventDefault();
    console.log("🚀 Login triggered with:", email, password); // debug

    try {
      const res = await axios.post('http://localhost:5000/api/auth/login', {
        email,
        password
      });

      console.log("✅ Login successful:", res.data); // debug
      localStorage.setItem('token', res.data.token);
      localStorage.setItem('role', res.data.role);
      onLogin(res.data.role); // 👈 must trigger App.js update
    } catch (err) {
      console.error("❌ Login failed", err);
      alert('Login failed');
    }
  };

  return (
    <form onSubmit={handleLogin} style={{ textAlign: 'center', marginTop: '80px' }}>
      <h2>{isAdmin ? 'Admin Login' : 'User Login'}</h2>
      <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="Email" required /><br /><br />
      <input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="Password" required /><br /><br />
      <button type="submit">Login</button>
    </form>
  );
};

export default Login;
