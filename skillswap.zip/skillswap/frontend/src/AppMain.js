import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AppMain = () => {
  const [user, setUser] = useState(null);
  const [selectedImage, setSelectedImage] = useState(null);
  const [isEditing, setIsEditing] = useState(false);
  const [form, setForm] = useState({ name: '', skillsOffered: '', skillsWanted: '' });
  const [searchSkill, setSearchSkill] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [mySwaps, setMySwaps] = useState([]);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    window.location.reload();
  };

  const handleImageChange = async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const formData = new FormData();
  formData.append('profilePhoto', file);

  try {
    const token = localStorage.getItem('token');
    const res = await axios.put('http://localhost:5000/api/users/me/photo', formData, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'multipart/form-data'
      }
    });

    setSelectedImage(res.data.profilePhoto);
    window.location.reload();
  } catch (err) {
    alert('Failed to upload profile picture');
    console.error(err);
  }
};


  const handleEditToggle = () => {
    if (user) {
      setForm({
        name: user.name || '',
        skillsOffered: user.skillsOffered?.join(', ') || '',
        skillsWanted: user.skillsWanted?.join(', ') || ''
      });
    }
    setIsEditing(true);
  };

  const handleFormChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFormSubmit = async (e) => {
    e.preventDefault();
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        'http://localhost:5000/api/users/me',
        {
          name: form.name,
          skillsOffered: form.skillsOffered.split(',').map(s => s.trim()),
          skillsWanted: form.skillsWanted.split(',').map(s => s.trim())
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      setIsEditing(false);
      window.location.reload();
    } catch (err) {
      console.error('❌ Failed to update profile:', err);
      alert('Failed to update profile.');
    }
  };

  const fetchMySwaps = async () => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get('http://localhost:5000/api/swaps/my-requests', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMySwaps(res.data);
    } catch (err) {
      console.error('❌ Failed to load my swaps:', err);
    }
  };

  const handleSearch = async () => {
  if (!searchSkill.trim()) {
    alert('Please enter a skill to search');
    return;
  }

  try {
    const res = await axios.get(`http://localhost:5000/api/users/search?skill=${searchSkill}`);
    const enrichedResults = res.data.map(u => ({
      ...u,
      mySkill: '',
      theirSkill: '',
      message: '',
      showForm: false
    }));
    setSearchResults(enrichedResults);
  } catch (err) {
    alert('Failed to search users');
    console.error(err);
  }
};

  const sendSwapRequest = async (recipient) => {
    const freshUser = searchResults.find(u => u._id === recipient._id);
    if (!freshUser) {
      alert('User not found in state');
      return;
    }

    const { mySkill, theirSkill, message } = freshUser;

    if (!freshUser._id || !mySkill || !theirSkill) {
      alert('Please select both your skill and the skill you want');
      return;
    }

    try {
      const token = localStorage.getItem('token');
      await axios.post(
        'http://localhost:5000/api/swaps',
        {
          recipientId: freshUser._id,
          skillRequested: theirSkill,
          skillOffered: mySkill,
          message
        },
        {
          headers: { Authorization: `Bearer ${token}` }
        }
      );
      alert(`✅ Swap request sent to ${freshUser.name}`);
    } catch (err) {
      console.error('❌ Failed to send swap request:', err);
      alert('Failed to send swap request');
    }
  };

  useEffect(() => {
    const fetchUser = async () => {
      try {
        const token = localStorage.getItem('token');
        const res = await axios.get('http://localhost:5000/api/users/me', {
          headers: { Authorization: `Bearer ${token}` }
        });
        setUser(res.data);
      } catch (err) {
        console.error('❌ Failed to fetch user:', err);
      }
    };
    fetchUser();
  }, []);

  if (!user) return <p>Loading...</p>;

  return (
    <div style={styles.container}>
      <div style={styles.topBar}>
        <div style={styles.welcome}>👤 Welcome, {user.name}</div>
        <button onClick={handleLogout} style={styles.logout}>Logout</button>
      </div>

      <div style={styles.profileCard}>
        <label htmlFor="profilePicInput">
          <img
            src={selectedImage || user.profilePhoto || 'https://via.placeholder.com/100'}
            alt="Profile"
            style={{ ...styles.avatar, cursor: 'pointer' }}
            title="Click to change profile picture"
            onClick={() => {
              fetchMySwaps();
              setShowProfileModal(true);
            }}
          />
        </label>
        <input
          id="profilePicInput"
          type="file"
          accept="image/*"
          style={{ display: 'none' }}
          onChange={handleImageChange}
        />

        <div>
          {!isEditing ? (
            <>
              <p><strong>Name:</strong> {user.name}</p>
              <p><strong>Email:</strong> {user.email}</p>
              <p>🎯 <strong>Skill Offered:</strong> {user.skillsOffered?.join(', ') || 'N/A'}</p>
              <p>💡 <strong>Wants to Learn:</strong> {user.skillsWanted?.join(', ') || 'N/A'}</p>
              <button style={styles.button} onClick={handleEditToggle}>Edit Profile</button>
            </>
          ) : (
            <form onSubmit={handleFormSubmit}>
              <input name="name" value={form.name} onChange={handleFormChange} placeholder="Name" required /><br />
              <input name="skillsOffered" value={form.skillsOffered} onChange={handleFormChange} placeholder="Skills Offered" /><br />
              <input name="skillsWanted" value={form.skillsWanted} onChange={handleFormChange} placeholder="Skills Wanted" /><br />
              <button type="submit" style={styles.button}>Save</button>
              <button type="button" onClick={() => setIsEditing(false)} style={{ ...styles.button, backgroundColor: '#ccc' }}>Cancel</button>
            </form>
          )}
        </div>
      </div>

      <div style={{ marginTop: '40px' }}>
        <h3 style={{ textAlign: 'center' }}>🔍 Find a User by Skill</h3>
        <div style={{ textAlign: 'center' }}>
          <input
            placeholder="Enter skill (e.g., React)"
            value={searchSkill}
            onChange={e => setSearchSkill(e.target.value)}
            style={{ padding: '8px', width: '60%', borderRadius: '6px', border: '1px solid #ccc' }}
          />
          <button
            onClick={handleSearch}
            style={{ marginLeft: '10px', padding: '8px 16px', borderRadius: '6px', backgroundColor: '#4caf50', color: 'white', border: 'none', cursor: 'pointer' }}
          >
            Search
          </button>
        </div>
      </div>
      <div style={{ marginTop: '30px' }}>
  {searchResults.length === 0 ? (
    <p style={{ textAlign: 'center', color: '#888' }}>No users found</p>
  ) : (
    searchResults.map(u => (
      <div
        key={u._id}
        style={{
          margin: '10px auto',
          padding: '10px 20px',
          border: '1px solid #ccc',
          borderRadius: '8px',
          maxWidth: '600px'
        }}
      >
        <p><strong>{u.name}</strong> | 📧 {u.email}</p>
        <p>🎯 Skills Offered: {u.skillsOffered?.join(', ')}</p>
        <p>💡 Wants to Learn: {u.skillsWanted?.join(', ')}</p>

        <label><strong>Your Skill:</strong></label><br />
        <select
          onChange={e => {
            setSearchResults(prev =>
              prev.map(item =>
                item._id === u._id ? { ...item, mySkill: e.target.value } : item
              )
            );
          }}
          style={{ padding: '6px', width: '100%', marginBottom: '10px' }}
        >
          <option value="">Select</option>
          {user.skillsOffered.map(skill => (
            <option key={skill} value={skill}>{skill}</option>
          ))}
        </select>

        <label><strong>Request Their Skill:</strong></label><br />
        <select
          onChange={e => {
            setSearchResults(prev =>
              prev.map(item =>
                item._id === u._id ? { ...item, theirSkill: e.target.value } : item
              )
            );
          }}
          style={{ padding: '6px', width: '100%', marginBottom: '10px' }}
        >
          <option value="">Select</option>
          {u.skillsOffered.map(skill => (
            <option key={skill} value={skill}>{skill}</option>
          ))}
        </select>

        <label><strong>Message:</strong></label><br />
        <textarea
          rows="2"
          placeholder="Say something..."
          onChange={e => {
            setSearchResults(prev =>
              prev.map(item =>
                item._id === u._id ? { ...item, message: e.target.value } : item
              )
            );
          }}
          style={{ padding: '6px', width: '100%', borderRadius: '6px', border: '1px solid #ccc' }}
        />

        <button
          onClick={() => sendSwapRequest(u)}
          style={{
            marginTop: '10px',
            backgroundColor: '#2ecc71',
            color: 'white',
            padding: '8px 16px',
            border: 'none',
            borderRadius: '6px',
            cursor: 'pointer'
          }}
        >
          Send Request
        </button>
      </div>
    ))
  )}
</div>


      {showProfileModal && (
        <div style={styles.modalBackdrop}>
          <div style={styles.modal}>
            <h2>📄 My Profile & Swap History</h2>
            <button onClick={() => setShowProfileModal(false)} style={styles.modalClose}>X</button>
            <div style={{ marginBottom: '20px' }}>
              <p><strong>Name:</strong> {user.name}</p>
              <p><strong>Email:</strong> {user.email}</p>
              <p><strong>Skills Offered:</strong> {user.skillsOffered.join(', ')}</p>
              <p><strong>Wants to Learn:</strong> {user.skillsWanted.join(', ')}</p>
            </div>
            <h3>📨 Sent Swap Requests</h3>
            {mySwaps.length === 0 ? (
              <p style={{ color: '#888' }}>No requests yet</p>
            ) : (
              mySwaps.map(swap => (
                <div key={swap._id} style={styles.swapItem}>
                  <p>
                    You offered <b>{swap.skillOffered}</b> in exchange for <b>{swap.skillRequested}</b> with <b>{swap.recipient.name}</b>
                    <br />Status: <b>{swap.status}</b>
                  </p>
                </div>
              ))
            )}
          </div>
        </div>
      )}
    </div>
  );
};

const styles = {
  container: {
    maxWidth: '800px',
    margin: '40px auto',
    padding: '20px',
    fontFamily: 'Arial, sans-serif',
    border: '1px solid #ddd',
    borderRadius: '10px',
    boxShadow: '0 0 10px rgba(0,0,0,0.1)'
  },
  topBar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px'
  },
  welcome: {
    fontSize: '20px',
    fontWeight: 'bold'
  },
  logout: {
    backgroundColor: '#e74c3c',
    color: 'white',
    border: 'none',
    padding: '8px 16px',
    borderRadius: '6px',
    cursor: 'pointer'
  },
  profileCard: {
    display: 'flex',
    gap: '20px',
    alignItems: 'flex-start',
    padding: '20px',
    border: '1px solid #eee',
    borderRadius: '10px',
    backgroundColor: '#f9f9f9'
  },
  avatar: {
    width: '100px',
    height: '100px',
    borderRadius: '50%',
    objectFit: 'cover'
  },
  button: {
    margin: '10px',
    padding: '10px 20px',
    border: 'none',
    borderRadius: '6px',
    backgroundColor: '#3498db',
    color: 'white',
    cursor: 'pointer'
  },
  modalBackdrop: {
    position: 'fixed',
    top: 0, left: 0, right: 0, bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  },
  modal: {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '10px',
    width: '600px',
    maxHeight: '80vh',
    overflowY: 'auto',
    position: 'relative'
  },
  modalClose: {
    position: 'absolute',
    top: '10px',
    right: '15px',
    background: 'transparent',
    fontSize: '20px',
    border: 'none',
    cursor: 'pointer'
  },
  swapItem: {
    borderBottom: '1px solid #ccc',
    padding: '10px 0'
  }
};

export default AppMain;
