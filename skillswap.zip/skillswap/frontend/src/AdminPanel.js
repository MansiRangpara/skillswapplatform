import React, { useEffect, useState } from 'react';
import axios from 'axios';

const AdminPanel = () => {
  const [users, setUsers] = useState([]);
  const [swaps, setSwaps] = useState([]);
  const [message, setMessage] = useState('');
  const [activeTab, setActiveTab] = useState('users'); // 'users' or 'swaps'

  const fetchData = async () => {
    try {
      const token = localStorage.getItem('token');
      const usersRes = await axios.get('http://localhost:5000/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const swapsRes = await axios.get('http://localhost:5000/api/swaps', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsers(usersRes.data);
      setSwaps(swapsRes.data);
    } catch (err) {
      console.error('❌ Fetch error:', err);
    }
  };

  const postMessage = async () => {
    try {
      const token = localStorage.getItem('token');
      await axios.post('http://localhost:5000/api/admin/message', { message }, {
        headers: { Authorization: `Bearer ${token}` }
      });
      alert('Message posted!');
    } catch (err) {
      alert('Failed to post message');
    }
  };

  const downloadReport = async (type) => {
    try {
      const token = localStorage.getItem('token');
      const res = await axios.get(`http://localhost:5000/api/admin/export?type=${type}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const blob = new Blob([JSON.stringify(res.data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${type}-report.json`;
      a.click();
    } catch (err) {
      alert('Failed to download report');
    }
  };

  const moderateUser = async (id, approved) => {
    try {
      await axios.put(`http://localhost:5000/api/admin/moderate/${id}`, { approved }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      alert(`Skill ${approved ? 'approved' : 'rejected'}`);
      fetchData();
    } catch (err) {
      alert('Moderation failed');
    }
  };

  const banUser = async (id, ban) => {
    try {
      await axios.put(`http://localhost:5000/api/admin/ban/${id}`, { ban }, {
        headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
      });
      alert(`User ${ban ? 'banned' : 'unbanned'}`);
      fetchData();
    } catch (err) {
      alert('Ban/unban failed');
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('role');
    window.location.reload();
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div style={{ padding: '20px' }}>
      <h2>🔧 Admin Panel</h2>
      <button onClick={handleLogout} style={{ float: 'right', marginBottom: '10px' }}>
        Logout
      </button>

      <h3>📢 Broadcast Message</h3>
      <textarea
        value={message}
        onChange={e => setMessage(e.target.value)}
        placeholder="Post a message for users"
        style={{ width: '100%', height: '80px', marginBottom: '10px' }}
      />
      <button onClick={postMessage}>Post Message</button>

      <h3>📥 Reports</h3>
      <button onClick={() => downloadReport('users')}>Download Users Report</button>
      <button onClick={() => downloadReport('swaps')}>Download Swaps Report</button>

      <h3>🗂 View</h3>
      <button
        onClick={() => setActiveTab('users')}
        style={{
          backgroundColor: activeTab === 'users' ? '#3498db' : '#eee',
          color: activeTab === 'users' ? 'white' : 'black',
          marginRight: '10px',
          padding: '8px 16px',
          borderRadius: '6px',
          border: 'none',
          cursor: 'pointer'
        }}
      >
        View Users
      </button>
      <button
        onClick={() => setActiveTab('swaps')}
        style={{
          backgroundColor: activeTab === 'swaps' ? '#3498db' : '#eee',
          color: activeTab === 'swaps' ? 'white' : 'black',
          padding: '8px 16px',
          borderRadius: '6px',
          border: 'none',
          cursor: 'pointer'
        }}
      >
        View Swaps
      </button>

      <div style={{ marginTop: '30px' }}>
        {activeTab === 'users' ? (
          <>
            <h3>🧑 Users</h3>
            {users.map(u => (
              <div key={u._id} style={{ borderBottom: '1px solid #ccc', paddingBottom: '10px', marginBottom: '10px' }}>
                <p><strong>{u.name}</strong> ({u.email})</p>
                <p>Skills Offered: {u.skillsOffered?.join(', ')} <br />
                  Wants to Learn: {u.skillsWanted?.join(', ')}</p>
                <p>Status: {u.isBanned ? '❌ Banned' : '✅ Active'} | Skills Approved: {u.isApproved ? '✅' : '❌'}</p>
                <button
                  onClick={() => banUser(u._id, !u.isBanned)}
                  style={{ backgroundColor: u.isBanned ? '#4caf50' : '#e74c3c', color: 'white', marginRight: '10px' }}
                >
                  {u.isBanned ? 'Unban' : 'Ban'}
                </button>
                <button
                  onClick={() => moderateUser(u._id, !u.isApproved)}
                  style={{ backgroundColor: u.isApproved ? '#e67e22' : '#2ecc71', color: 'white' }}
                >
                  {u.isApproved ? 'Reject Skills' : 'Approve Skills'}
                </button>
              </div>
            ))}
          </>
        ) : (
          <>
            <h3>🔁 Swaps</h3>
            {swaps.map(s => (
              <div key={s._id} style={{ marginBottom: '10px' }}>
                <p>
                  <strong>{s.requester?.name}</strong> offered <b>{s.skillOffered}</b> <br />
                  for <b>{s.skillRequested}</b> with <strong>{s.recipient?.name}</strong> <br />
                  Status: <b>{s.status}</b>
                </p>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
};

export default AdminPanel;
