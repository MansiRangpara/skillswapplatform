import React, { useEffect, useState } from 'react';
import Welcome from './Welcome';
import Login from './login'; // make sure this file is named Login.js
import Register from './Register';
import AppMain from './AppMain';
import AdminPanel from './AdminPanel';

const App = () => {
  const [page, setPage] = useState('welcome');
  const [role, setRole] = useState(null);

  // Load role from localStorage (on reload or after login)
  useEffect(() => {
    const savedRole = localStorage.getItem('role');
    console.log("Loaded role from storage:", savedRole); // 👈 debug line
    if (savedRole) setRole(savedRole);
  }, []);

  const handleAuth = (loggedInRole) => {
    console.log("Setting role after login:", loggedInRole); // 👈 debug line
    localStorage.setItem('role', loggedInRole);
    setRole(loggedInRole);
  };

  if (role === 'admin') return <AdminPanel />;
  if (role === 'user') return <AppMain />;

  switch (page) {
    case 'welcome':
      return <Welcome onSelect={setPage} />;
    case 'login':
      return <Login onLogin={handleAuth} />;
    case 'register':
      return <Register onRegister={handleAuth} />;
    case 'admin':
      return <Login isAdmin={true} onLogin={handleAuth} />;
    default:
      return <Welcome onSelect={setPage} />;
  }
};

export default App;
