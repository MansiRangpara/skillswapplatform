
import React, { useState } from 'react';
import axios from 'axios';

const UserForm = ({ onUserCreated }) => {
  const [formData, setFormData] = useState({
    name: '',
    location: '',
    skillsOffered: '',
    skillsWanted: '',
    availability: 'Evenings',
    isPublic: true,
  });

  const handleChange = e => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value,
    }));
  };

  const handleSubmit = async e => {
    e.preventDefault();
    const payload = {
      ...formData,
      skillsOffered: formData.skillsOffered.split(',').map(s => s.trim()),
      skillsWanted: formData.skillsWanted.split(',').map(s => s.trim()),
    };
    await axios.post('http://localhost:5000/api/users', payload);
    onUserCreated();
  };

  return (
    <form onSubmit={handleSubmit} style={{ marginBottom: '2rem' }}>
      <h3>Create User</h3>
      <input name='name' placeholder='Name' onChange={handleChange} required /><br />
      <input name='location' placeholder='Location' onChange={handleChange} /><br />
      <input name='skillsOffered' placeholder='Skills Offered (comma separated)' onChange={handleChange} /><br />
      <input name='skillsWanted' placeholder='Skills Wanted (comma separated)' onChange={handleChange} /><br />
      <select name='availability' onChange={handleChange}>
        <option value='Evenings'>Evenings</option>
        <option value='Weekends'>Weekends</option>
      </select><br />
      <label>
        Public Profile: <input type='checkbox' name='isPublic' checked={formData.isPublic} onChange={handleChange} />
      </label><br />
      <button type='submit'>Submit</button>
    </form>
  );
};

export default UserForm;
