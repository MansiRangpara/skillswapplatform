import React from 'react';

const Welcome = ({ onSelect }) => {
  const buttonStyle = {
    padding: '12px 25px',
    margin: '10px',
    borderRadius: '8px',
    backgroundColor: '#4A90E2',
    color: 'white',
    fontSize: '16px',
    border: 'none',
    cursor: 'pointer'
  };

  const containerStyle = {
    textAlign: 'center',
    marginTop: '100px',
    fontFamily: 'Arial, sans-serif'
  };

  return (
    <div style={containerStyle}>
      <h1>👋 Welcome to Skill Swap</h1>
      <p style={{ fontSize: '18px' }}>Choose how you'd like to begin:</p>
      <div>
        <button onClick={() => onSelect('register')} style={buttonStyle}>Register as User</button>
        <br />
        <button onClick={() => onSelect('login')} style={buttonStyle}>Login as User</button>
        <br />
        <button onClick={() => onSelect('admin')} style={{ ...buttonStyle, backgroundColor: '#d9534f' }}>Login as Admin</button>
      </div><button
  onClick={() => {
    localStorage.clear();
    window.location.reload();
  }}
>
  Reset App
</button>

    </div>
    
  );
};

export default Welcome;
